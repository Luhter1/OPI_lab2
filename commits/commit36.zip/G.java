public class G implements I {

    private String e = "hello";

    private long d = 1234;

    public Object pp() {
        return this;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public byte oo() {
        return 2;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public void aa() {
        return;
    }

    public void ab() {
        return;
    }

    public int af() {
        return -1;
    }

    public long dd() {
        return 33;
    }
}
