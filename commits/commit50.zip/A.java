public class A extends null {

    int cc();

    int ae();

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public double ee() {
        return 100.500;
    }
}
