public class I extends null {

    int hh();

    java.util.Random mm();

    public Object rr() {
        return null;
    }

    public void ab() {
        return;
    }

    public Object gg() {
        return new java.util.Random();
    }
}
