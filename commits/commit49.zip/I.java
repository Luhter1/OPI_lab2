public class I extends null {

    int hh();

    java.util.Random mm();

    public void ab() {
        System.out.println("\n");
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object pp() {
        return this;
    }
}
