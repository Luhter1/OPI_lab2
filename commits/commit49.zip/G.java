public class G extends null implements I {

    private String e = "hello";

    private long d = 1234;

    public Object pp() {
        return this;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public byte oo() {
        return 2;
    }

    public int af() {
        return -1;
    }

    public long dd() {
        return 33;
    }

    public Object rr() {
        return null;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public void aa() {
        return;
    }

    public void ab() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public String kk() {
        return "No";
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public double ee() {
        return 500.100;
    }

    public float ff() {
        return 0;
    }

    public int ae() {
        return 8;
    }

    public int cc() {
        return 42;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
