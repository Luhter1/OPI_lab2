public class A extends null {

    int cc();

    int ae();

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 500.100;
    }

    public void bb() {
        System.out.println(42);
    }
}
