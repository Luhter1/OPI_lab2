public class I extends null {

    int hh();

    java.util.Random mm();

    public long ac() {
        return 333;
    }
}
