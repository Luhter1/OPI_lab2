public class A extends null {

    int cc();

    int ae();

    public double ad() {
        return 11.09;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
