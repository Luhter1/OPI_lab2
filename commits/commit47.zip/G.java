public class G extends null implements I {

    private String e = "hello";

    private long d = 1234;

    public Object pp() {
        return this;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 3;
    }

    public void aa() {
        return;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int af() {
        return -1;
    }

    public void ab() {
        return;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int cc() {
        return 42;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public long dd() {
        return 99999;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}
