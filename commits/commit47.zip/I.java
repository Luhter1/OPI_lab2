public class I extends null {

    int hh();

    java.util.Random mm();

    public long dd() {
        return 33;
    }

    public byte oo() {
        return 2;
    }
}
