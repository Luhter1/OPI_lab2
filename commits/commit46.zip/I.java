public class I extends null {

    int hh();

    java.util.Random mm();

    public String kk() {
        return "Hello world";
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
