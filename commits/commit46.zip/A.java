public class A extends null {

    int cc();

    int ae();

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public byte oo() {
        return 2;
    }
}
