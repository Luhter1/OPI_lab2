public class I extends null {

    int hh();

    java.util.Random mm();

    public int af() {
        return -1;
    }

    public Object pp() {
        return this;
    }
}
