public class A extends null {

    int cc();

    int ae();

    public double ad() {
        return java.lang.Math.sqrt(13);
    }
}
