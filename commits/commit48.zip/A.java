public class A extends null {

    int cc();

    int ae();

    public void aa() {
        return;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.lang.Class qq() {
        return getClass();
    }
}
