public class G extends null implements I {

    private String e = "hello";

    private long d = 1234;

    public Object pp() {
        return this;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public byte oo() {
        return 1;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public void aa() {
        return;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public int af() {
        return -1;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public long dd() {
        return 99999;
    }

    public double ee() {
        return 0.000001;
    }

    public float ff() {
        return 0;
    }

    public void ab() {
        System.out.println("\n");
    }

    public String kk() {
        return "No";
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
