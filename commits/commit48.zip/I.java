public class I extends null {

    int hh();

    java.util.Random mm();

    public long ac() {
        return 333;
    }

    public Object rr() {
        return null;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }
}
