public class H extends null implements A {

    private byte b = 1;

    private int f = 1;

    public float ff() {
        return 3.14;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int cc() {
        return 42;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public long ac() {
        return 222;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public String kk() {
        return "Hello world";
    }
}
