public class I extends null {

    int hh();

    java.util.Random mm();
}
